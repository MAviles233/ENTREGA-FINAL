/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto_cafeteria;

/**
 *
 * @author Grupo 1 - Proyecto Cafeteria - Curso 6-2
 */
public class Proyecto_Cafeteria {

    /**
     * Metodo main para ejecutar el programa
     */
    public static void main(String[] args) {
        LoginFrame p = new LoginFrame();
        p.setVisible(true);
        p.setLocationRelativeTo(null);
    }
    
}
